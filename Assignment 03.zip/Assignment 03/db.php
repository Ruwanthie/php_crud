<?php
	$servername="localhost";
	$username="root";
	$password="";
	$conn=mysqli_connect($servername,$username,$password);
	if(!$conn){
		die("connection failed:".mysqli_connect_error());
		}
	else
	{
	echo "DB Connected successfully";
	mysqli_select_db($conn,"registerdb_042");
	}
?>
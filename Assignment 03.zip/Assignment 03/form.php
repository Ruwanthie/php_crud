<!DOCTYPE html>
<html>
<head>
<style>
div{
	border-bottom: double;
	border-left: double;
	border-right:double;
	border-top:double;
	max-width:400px;
}
table {
	border-bottom: double;
	}
</style>
<script>
function check_letters(Theform)
      { 
	  var x=document.forms["register"]["name"].value;
	  if(x=="")
		{
			alert("Name must be filled out");
			return false;
		}
		else if(!/^[A-Za-z]+$/.test(x))
		{
			alert("Please input alphabet characters only!!");
			return false;
		}
	  else 
		 return true;
	  }
		  
function check_contactno(Theform)
{ 
	var z=document.forms["register"]["contactno"].value;
	if(z=="")
	{
		alert(" Contact Number must be filled out!!");
		return false;
	}
	else if(!/^[0-9]+$/.test(z))
        {
        alert("Please only enter numeric characters only!!!");
		return false;
        }
 }
function check_nic(Theform)
{
	var y=document.forms["register"]["nic"].value;
	if(y=="")
	{
		alert("NIC must be filled out!!");
		return false;
	}
	else if(!/^[0-9]{9}[vVxX]$/.test(y))
		{
			alert("Please Enter a valid NIC number!!!");
			return false;
		}
}
function check_email(Theform) 
{
	var e=document.forms["register"]["email"].value;
	if (!/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(e))
  {
    alert("You have entered an invalid email address!");
    return false;
  }
}
		
</script>
</head>
<body>
<?php
	require('db.php');
	if(isset($_POST['register'])){
		$name=mysqli_real_escape_string($conn,$_POST['name']);
		$contactno=mysqli_real_escape_string($conn,$_POST['contactno']);
		$nic=mysqli_real_escape_string($conn,$_POST['nic']);
		$course=mysqli_real_escape_string($conn,$_POST['course']);
		$email=mysqli_real_escape_string($conn,$_POST['email']);
		
	$sql="INSERT INTO registertbl_042(fullname,contactno,nic,course,email) VALUES ($name,$contactno,$nic,$course,$email)";
	$result=mysqli_query($conn,$sql);
	if($result)
		{
			echo("Registration Completed");
		}
	else
		{
			echo("Registration Failed");
		}
	}
	
	
?>
		
	<h1>Register for courses</h1>
	<div>
	<form name="register" onsubmit="return checkform(register)" method="post">
	<table width="400px">
		<tr><td>Full Name:</td><td><input type="text" name="name" onBlur=" return check_letters(register)"></td></tr>
		<tr><td>Contact Number:</td><td><input type="text" name="contactno" onBlur="return check_contactno(register)" maxlength="10"></td></td>
		<tr><td>NIC:</td><td><input type="text" name="nic" onBlur="return check_nic(register)"></td></tr>
		<tr>
			<td>Course:</td>
			<td>
				<select name="course" required>
					<option value="bit">BIT</option>
					<option value="bcs">BCS</option>
					<option value="cima">CIMA</option>
					<option value="aat">AAT</option>
				</select>
			</td>
		</tr>
		<tr><td>Email:</td><td><input type="text" name="email" required onBlur="return check_email(register)" ></td></tr>
		<tr style="text-align:center"><td><input type="submit" name="register" value="Register"></td><td><input type="reset" name="clear" value="Clear"></td></tr>
		</table>
	</form>
	<p>If you are already registered,View Your Details here....<br><br>
	NIC:<input type="text" name="nicview">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
	<input type="button" value="View" name="view"></p>
	</div>
</body>
</html>
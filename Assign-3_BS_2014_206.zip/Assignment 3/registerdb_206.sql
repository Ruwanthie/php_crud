-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 15, 2018 at 07:23 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `registerdb_206`
--

-- --------------------------------------------------------

--
-- Table structure for table `registertbl_206`
--

CREATE TABLE `registertbl_206` (
  `registration_no` int(10) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `contact_no` int(20) NOT NULL,
  `nic` varchar(20) NOT NULL,
  `course` varchar(50) NOT NULL,
  `email` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registertbl_206`
--

INSERT INTO `registertbl_206` (`registration_no`, `full_name`, `contact_no`, `nic`, `course`, `email`) VALUES
(1, 'Dasuni Perera', 764805857, '948000075V', 'BIT', 'das.perera@yahoo.com'),
(2, 'Isara Didulantha', 717805220, '973161504V', 'BIT', 'isara.didulantha123@gmail.com'),
(3, 'Deepani Siriwardane', 775812959, '687511242V', 'BCS', 'did.perera123@gmail.com'),
(4, 'Hasali Dimanthie', 332261728, '785601389V', 'CIMA', 'hsd@yahoo.com'),
(5, 'Pubudu Kaviranga', 771226604, '947040023V', 'AAT', 'pubudu@gmail.com'),
(6, 'Yasasi Gangi', 117208969, '951010142V', 'BCS', 'yasasi_g@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `registertbl_206`
--
ALTER TABLE `registertbl_206`
  ADD PRIMARY KEY (`registration_no`),
  ADD UNIQUE KEY `nic_key` (`nic`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `registertbl_206`
--
ALTER TABLE `registertbl_206`
  MODIFY `registration_no` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

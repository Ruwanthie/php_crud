<?php
// START SESSION
session_start();
require('connection.php');
$id = $_GET['id'];
?>
<!DOCTYPE html>
<html>
<head>
	<title>View Details</title>
	<style type="text/css">
		table, th, td {
		  border: 1px solid black;
		  border-collapse: collapse;
		}
	</style>
</head>

<body>
<h1>Your Details are Registered With NIC : <?php echo $id; ?></h1>

<table>
	<thead>
		<th>&nbsp;&nbsp;&nbsp;&nbsp;Full Name&nbsp;&nbsp;&nbsp;&nbsp;</th>
		<th>&nbsp;&nbsp;&nbsp;&nbsp;Contact Number&nbsp;&nbsp;&nbsp;&nbsp;</th>
		<th>&nbsp;&nbsp;&nbsp;&nbsp;Course&nbsp;&nbsp;&nbsp;&nbsp;</th>
		<th>&nbsp;&nbsp;&nbsp;&nbsp;NIC&nbsp;&nbsp;&nbsp;&nbsp;</th>
		<th>&nbsp;&nbsp;&nbsp;&nbsp;Email&nbsp;&nbsp;&nbsp;&nbsp;</th>
	</thead>
	<tbody>
		<tr>
			<?php

            $id = $_GET['id'];                
            $query=mysqli_query($db,"SELECT * FROM registertbl_206 WHERE nic LIKE '%{$id}%'");
            while($row=mysqli_fetch_array($query)){
                ?>
                <tr>
                    <td><?php echo $row['full_name']; ?></td>
                    <td><?php echo $row['contact_no']; ?></td>
                    <td><?php echo $row['course']; ?></td>
                    <td><?php echo $row['nic']; ?></td>
                    <td><?php echo $row['email']; ?></td>
		</tr>
		<?php
		         }

		?>
	</tbody>
</table>
</body>
</html>
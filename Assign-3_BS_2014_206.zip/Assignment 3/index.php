<?php
// START SESSION
session_start();
require('connection.php');

?>
<!DOCTYPE html>
<html>
<head>
    <title>Question</title>
</head>
<body>
<script> 
function validate()                                    
{ 
    var full_name = document.forms["registerationForm"]["full_name"];               
    var email = document.forms["registerationForm"]["email"];    
    var nic = document.forms["registerationForm"]["nic"];  
   
   
    if (full_name.value == "")                                  
    { 
        window.alert("Please enter your name."); 
        full_name.focus(); 
        return false; 
    } 
   
    if (email.value == "")                               
    { 
        window.alert("Please enter your email address."); 
        email.focus(); 
        return false; 
    } 
       
    if (nic.value == "")                                   
    { 
        window.alert("Please enter your nic."); 
        nic.focus(); 
        return false; 
    } 
   
    if (email.value.indexOf("@", 0) < 0)                 
    { 
        window.alert("Please enter a valid e-mail address."); 
        email.focus(); 
        return false; 
    } 
   
    if (email.value.indexOf(".", 0) < 0)                 
    { 
        window.alert("Please enter a valid e-mail address."); 
        email.focus(); 
        return false; 
    } 
    return true; 
}</script> 
<?php
require('connection.php');
if (isset($_POST['save_btn']) ) {

        $full_name= mysqli_real_escape_string($db,$_POST['full_name']);
        $contact_no= mysqli_real_escape_string($db,$_POST['contact_no']);
        $nic= mysqli_real_escape_string($db,$_POST['nic']);  
        $course= mysqli_real_escape_string($db,$_POST['course']);
        $email= mysqli_real_escape_string($db,$_POST['email']);
   
        $sql = "INSERT INTO registertbl_206(full_name,contact_no,nic,course,email) VALUES ('$full_name','$contact_no','$nic','$course','$email')";
        $result = mysqli_query($db, $sql);
        if ($result) {
            echo 'Registration completed!';
        } 
        else {
            echo 'Registration Failed.';
        }
    }

    if (isset($_POST['View']) ) {
        $nic= mysqli_real_escape_string($db,$_POST['nic']);
        header("Location: view.php?id=$nic");
    }
?>
<h1>Register For Courses</h1>
<form method="post" style="border-style: double; width: 30%;" id="registerationForm" onsubmit="return validate()">   
    <table >
    <tr >
        <td>Full Name : </td>
        <td>
            <input type="text" name="full_name" id="full_name"  required="" />
        </td>
    </tr>
    <tr>
        <td>Contact Number : </td>
        <td>
            <input type="tel" name="contact_no" id="contact_no"  />
        </td>
    </tr>
    <tr>
        <td>NIC : </td>
        <td>
            <input type="text" name="nic" id="nic" required="" />
        </td>
    </tr>
    <tr>
        <td>Course : </td>
        <td>
            <select name="course" id="course">
                <option>BIT</option>
                <option>BCS</option>
                <option>CIMA</option>
                <option>AAT</option>
            </select>
        </td>
    </tr>
    <tr>
        <td>Email : </td>
        <td>
            <input type="email" name="email" id="email" required="" title="Please enter a valid email"/>
        </td>
    </tr>
     <tr>
        <td></td>
        <td>
            <input type="submit" value="REGISTER" id="save_btn" name="save_btn"/>
            <input type="reset" value="CLEAR" id="Clear" name="Clear"/>
        </td>       
    </tr>
</table>
</form>

<form method="post" style="border-style: double; width: 30%;"> 
    <table >
     <tr>
        <td>If you are already registered, View Your Details here...</td>
        <td></td>
    </tr>
    <tr style="border-style: double;">
        <td>NIC : &nbsp;&nbsp;
            <input type="text" name="nic" id="nic" title="Invalid Format (Ex:948000075V or 948000075v)" required="" />
        </td>
        <td>
            <input type="submit" value="VIEW" id="View" name="View"/>
        </td>
    </tr>
</table>
</form>
</body>
</html>

